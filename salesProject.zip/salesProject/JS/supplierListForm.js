function getSupplierForm(){
		var supplierForm = `
					<div class="salesProjectSupplierHeaderRowCls">
						<div class="salesProjectCustomerHdrLblRowCls">
							<label class="salesProjectSupplierHdrLblCls">Supplier Details</label>
						</div>
						<div class="salesProjectBillingRightHdrLblRowCls">
							<select class="salesProjectBillingRightProductSelectList2Cls" id="supplier_name_or_area_or_phone_select_tag">
								<option>Name </option>
								<option>Area </option>
								<option>Phone </option>
							</select>
						</div>
						<div class="salesProjectCustomerAddLblRowCls" onclick="supplierFormSearch()">	
							<label class="salesProjectCustomerHdr1LblCls">Search</label>
						</div>
						<div class="salesProjectCustomerAddLblRowCls" onclick="showSupplierDetailsForm()">
							<label class="salesProjectSupplierHdr1LblCls">Add</label>
						</div>
					</div>
					<div class="salesProjectSupplierBodyRowCls">
						<div class="salesProjectItemBodyHdrInnerTHeadCls">
						 
							<div class="salesProjectItemBodyInnerTHRow1Cls">Customer Name</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Area</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Phone</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Cash In Hand</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Payment Pending</div>
						</div>
						<div class="salesProjectItemBodytBodyInnerRowCls" id="supplierlist_body_container">
							
						<div>
					</div>`;
		return supplierForm;
	}

function clearAllSupplierText(){
	document.getElementById("supplierForm_supplier_name").value = "";
	document.getElementById("supplierForm_area").value = "";
	document.getElementById("supplierForm_phone_no").value = "";
	document.getElementById("supplierForm_cash_in_hand").value = "";
	document.getElementById("supplierForm_payment_pending").value = "";
}

function showSupplierDetailsForm(){
	hideAllForm();
	document.getElementById("salesProjectMainForm").style.display ="block";
	document.getElementById("salesProjectSupplierAddForm").style.display ="block";
	clearAllSupplierText();
}

function supplierFormSearch(){
	var typeOfSearch = document.getElementById("supplier_name_or_area_or_phone_select_tag").value;
	if(typeOfSearch == "Name"){
			var name = prompt("Enter the name to search :");
		}else if(typeOfSearch == "Area"){
			var area = prompt("Enter the area to search :");
		}else if(typeOfSearch == "Phone"){
			var phoneNo = prompt("Enter the phone number to search :");
		}else{

		}
}