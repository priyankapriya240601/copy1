function getBillingForm(){
		var billingForm = `
					<div class="salesProjectBillingLeftFormCls" >
						<div class="salesProjectBillingLeftHeaderRowCls">
							<div class="salesProjectBillingLeftHdrLblRowCls">
								<label class="salesProjectBillinLeftHdrLblCls">Product Type</label>
							</div>
							<div class="salesProjectBillingLeftSelectTagRowCls">
								<select class="salesProjectBillingLeftProductSelectListCls">
									<option>vegetable</option>
								</select>
							</div>
						</div>
						<div class="salesProjectBillingLeftBodyRowCls" id="salesProjectBillingItemImgesListBodyContainer">
							
						</div>			
					</div>
					<div class="salesProjectBillingRightFormCls" >
						<div class="salesProjectBillingRightHeaderRowCls">
							<div class="salesProjectBillingRightHdrLblRowCls">
								<label class="salesProjectBillinLeftHdrLblCls">Billing Type :</label>
							</div>
							<div class="salesProjectBillingRightSelectTagRowCls">
								<select class="salesProjectBillingRightProductSelectListCls" id="billing_supplier_or_customer_select_tag">
									<option>Supplier </option>
									<option>Customer </option>
								</select>
							</div>
							<div class="salesProjectBillingRightHdrLblRowCls">
								<select class="salesProjectBillingRightProductSelectListCls" id="billing_name_or_area_or_phone_select_tag">
									<option>Name </option>
									<option>Area </option>
									<option>Phone </option>
								</select>
							</div>
							<div class="salesProjectBillingRightSelectTagRowCls">	
								<button class="salesProjectBillingExportBtnCls" onclick="billingFormSearch()">Search</button>
							</div>
							<div class="salesProjectBillingRightSelectTagRowCls">	
								<button class="salesProjectBillingExportBtnCls" onclick="showExportForm()">export</button>
							</div>
						</div>
						<div class="salesProjectBillingRightBodyRowCls">
							
						</div>					
					</div>			`;
		return billingForm;
	}

function billingFormSearch(){
		var typeOfSearch = document.getElementById("billing_name_or_area_or_phone_select_tag").value;
		if(typeOfSearch == "Name"){
			var name = prompt("Enter the name to search :");
		}else if(typeOfSearch == "Area"){
			var area = prompt("Enter the area to search :");
		}else if(typeOfSearch == "Phone"){
			var phoneNo = prompt("Enter the phone number to search :");
		}else{

		}
}
		

	function showExportForm(){
		hideAllForm();
		document.getElementById("salesProjectMainForm").style.display = "block";
		document.getElementById("salesProjectExportPDFForm").style.display = "block";
		document.getElementById("salesProjectExportPDFForm").innerHTML = getExportPDFForm();
	}

	function billingItemImagesHTML(imgsrcObj){
		var row = `<div class="salesProjectBillingFormItemImgRowCls"><img src="`+imgsrcObj+`" class="salesProjectBillingFormItemImgCls"></div>`;
		return row;
	}