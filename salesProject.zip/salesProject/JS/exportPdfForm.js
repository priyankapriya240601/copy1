function getExportPDFForm(){
	var exportForm = `<div class="salesProjectExportPDFFormHdrRowCls">
			<div class="salesProjectExportPDFFormHdrCloseRowCls" onclick="hideExportPDFForm()">
				<label class="salesProjectExportPDFFormHdrCloseLblCls">&times;</label>
			</div>
		</div>
		<iframe class="salesProjectExportPDFFormBodyRowCls" id="salesProjectExportPDFBodyContainer">
			
		</iframe>`;
	return exportForm;
}

function hideExportPDFForm(){
	document.getElementById("salesProjectExportPDFForm").style.display = "none";
}