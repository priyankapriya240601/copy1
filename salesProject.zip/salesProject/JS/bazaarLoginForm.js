function getLoginSalesForm(){
		var loginSalesForm = `
		<div class="loginsalesProjectinnerBoxCls">
			<div class="loginsalesProjectinnerboxheaderCls">
				<label class="loginSalesProjectHeaderLBLCls">login</label>
			</div>
			<div class="loginsalesProjectinnerboxbodyCls">
				<fieldset class="loginSalesProjectRowCls">
					<legend>User Name</legend>
					<input type="text" class="loginSalesInputCls" id="bazaar_project_login_username">
				</fieldset>
				<fieldset class="loginSalesProjectRowCls">
					<legend>Password</legend>
					<input type="password" class="loginSalesInputCls" id="bazaar_project_login_password">
				</fieldset>

			</div>
			<div class="loginsalesProjectinnerboxfooterCls">
				<button class="loginClearSalesBtnCls" onclick="loginClearTextBox()">Clear</button>
				<button class="loginSubmitSalesBtnCls" onclick="loginCheckingProcess()">Submit</button>
			</div>
		</div>`;
		return loginSalesForm;
	}



function loginCheckingProcess(){
	var username = document.getElementById("bazaar_project_login_username").value;
	var password = document.getElementById("bazaar_project_login_password").value;

	if(username == "admin" && password == "admin123"){
		hideAllForm();
		document.getElementById("salesProjectMainForm").style.display = "block";
	}else{
		hideAllForm();
		document.getElementById("loginSalesProjectForm").style.display = "block";
		document.getElementById("bazaar_project_login_username").value = "";
		document.getElementById("bazaar_project_login_password").value = "";
		alert("login Failed...")
	}
}

function loginClearTextBox(){
	document.getElementById("bazaar_project_login_username").value ="";
	document.getElementById("bazaar_project_login_password").value = "";

}