	
	function getAddSupplierForm(){
		var addSupplierForm = `
			<div class="salesProjectProductAddInnerFormCls">
				<div class="salesProjectProductAddInnerHdrRowCls">
					<div class="salesProjectAddProductHdrLblRowCls">
						<label class="salesProjectProdctAddInnerMainHdrLblCls">Supplier Details</label>
					</div>
					<div class="salesProjectAddProductAddLblMainRowCls" onclick="hideSupplierDetailsForm()">
						<label class="salesProjectProdctAddInnerMainHdrLblCls" >&times;</label>
					</div>
				</div>
				<div class="salesProjectProductAddInnerBodyRowCls">
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Supplier name</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="supplierForm_supplier_name" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Area</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls"  id="supplierForm_area" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Phone No</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="supplierForm_phone_no"  autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<div class="salesProjectAddSupplierHdrLblRow1Cls">
							<label class="salesProjectSupplierAddInnerHdrLblCls">Cash In Hand</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls" onclick="addSupplierNewCashInHand()">
							<label class="salesProjectProdctAddInnerHdrLblCls">&plus;</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls" onclick="subSupplierNewCashInHand()">
							<label class="salesProjectProdctAddInnerHdrLblCls">&minus;</label>
						</div>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="supplierForm_cash_in_hand"  autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<div class="salesProjectAddSupplierHdrLblRow1Cls">
							<label class="salesProjectSupplierAddInnerHdrLblCls">Payment Pending</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls">
							<label class="salesProjectProdctAddInnerHdrLblCls" onclick="addSupplierNewPaymentPending()">&plus;</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls"  onclick="subSupplierNewPaymentPending()">
							<label class="salesProjectProdctAddInnerHdrLblCls">&minus;</label>
						</div>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="supplierForm_payment_pending"  autocomplete="off">
					</div>
				</div>
				<div class="salesProjectProductAddInnerFtrRowCls">
					<button class="itemClearSalesBtnCls" onclick="clearAllSupplierText();()">Clear</button>
					<button class="itemSubmitSalesBtnCls" onclick="updateNewSupplier()">Update</button>
				</div>
		</div>	`;
		return addSupplierForm;
	}

function supplierDynamicRowHTML(customerName,area,phoneNo,cashInHand,paymentPending){
		var row = `<div class="salesProjectItemBodyBdyInnerTRowCls">
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+customerName+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+area+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+phoneNo+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+cashInHand+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+paymentPending+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow2Cls">
							<label class="salesProjectItemBodyBdyInnerTdLbl1Cls" onclick="deleteSupplierDynamicRowHTML(this)">&times;</label>
						</div>
					</div>`;
		return row;
	}

	function hideSupplierDetailsForm(){
		document.getElementById("salesProjectSupplierAddForm").style.display ="none";
	} 



	function updateNewSupplier(){

		try{
			var customerName = document.getElementById("supplierForm_supplier_name").value;
			var area = document.getElementById("supplierForm_area").value;
			var phoneNo = document.getElementById("supplierForm_phone_no").value;
			var cashInHand = document.getElementById("supplierForm_cash_in_hand").value;
			var paymentPending = document.getElementById("supplierForm_payment_pending").value;
		
			var bodyContainer = document.getElementById("supplierlist_body_container");
			var bodyContainerInnerHTML = document.getElementById("supplierlist_body_container").innerHTML;
			var row = supplierDynamicRowHTML(customerName,area,phoneNo,cashInHand,paymentPending);
			bodyContainer.innerHTML = bodyContainerInnerHTML + row;

			document.getElementById("salesProjectSupplierAddForm").style.display ="none";
			document.getElementById("salesProjectMainForm").style.display = "block";
		
		}catch(exp){
			alert(exp);
		}

	}

	function deleteSupplierDynamicRowHTML(obj){
		obj.parentNode.parentNode.remove();
	}

	function addSupplierNewCashInHand(){
		try{
			var newCashInHand = prompt("Add Cash In Hand :");
			if(newCashInHand != null){
				newCashInHand = parseInt(newCashInHand);
				var oldCashInHand = document.getElementById("supplierForm_cash_in_hand").value;
				document.getElementById("supplierForm_cash_in_hand").value = oldCashInHand+newCashInHand;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function subSupplierNewCashInHand(){
		try{
			var newCashInHand = prompt("Sub Cash In Hand :");
			if(newCashInHand != null){
				newCashInHand = parseInt(newCashInHand);
				var oldCashInHand = document.getElementById("supplierForm_cash_in_hand").value;
				document.getElementById("supplierForm_cash_in_hand").value = oldCashInHand-newCashInHand;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function addSupplierNewPaymentPending(){
		try{
			var newPaymentPending = prompt("Add Payment Pending :");
			if(newPaymentPending != null){
				newPaymentPending = parseInt(newPaymentPending);
				var oldPaymentPending = document.getElementById("supplierForm_payment_pending").value;
				document.getElementById("supplierForm_payment_pending").value = oldPaymentPending+newPaymentPending;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function subSupplierNewPaymentPending(){
		try{
			var newPaymentPending = prompt("Sub Cash In Hand :");
			if(newPaymentPending != null){
				newPaymentPending = parseInt(newPaymentPending);
				var oldPaymentPending = document.getElementById("supplierForm_payment_pending").value;
				document.getElementById("supplierForm_payment_pending").value = oldPaymentPending-newPaymentPending;
			}
		}catch(exp){
			alert(exp);
		}
	}