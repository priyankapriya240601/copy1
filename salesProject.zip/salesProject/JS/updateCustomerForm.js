	function getAddCustomerForm(){
		var addCustomerForm = `
			<div class="salesProjectProductAddInnerFormCls">
				<div class="salesProjectProductAddInnerHdrRowCls">
					<div class="salesProjectAddProductHdrLblRowCls">
						<label class="salesProjectProdctAddInnerMainHdrLblCls">Customer Details</label>
					</div>
					<div class="salesProjectAddProductAddLblMainRowCls" >
						<label class="salesProjectProdctAddInnerMainHdrLblCls" onclick="hideCustomerDetailsForm()">&times;</label>
					</div>
				</div>
				<div class="salesProjectProductAddInnerBodyRowCls">
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Customer name</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="addCustomer_customer_name_txt" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Area</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="addCustomer_area_txt" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<label class="salesProjectSupplierDetailsEnterLblCls">Phone No</label>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="addCustomer_phone_no_txt" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<div class="salesProjectAddSupplierHdrLblRow1Cls">
							<label class="salesProjectSupplierAddInnerHdrLblCls">Cash In Hand</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls" onclick="addCustomerNewCashInHand()">
							<label class="salesProjectProdctAddInnerHdrLblCls">&plus;</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls">
							<label class="salesProjectProdctAddInnerHdrLblCls" onclick="subCustomerNewCashInHand()">&minus;</label>
						</div>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="addCustomer_cash_in_hand_txt" autocomplete="off">
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<div class="salesProjectAddSupplierHdrLblRow1Cls">
							<label class="salesProjectSupplierAddInnerHdrLblCls">Payment Pending</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls">
							<label class="salesProjectProdctAddInnerHdrLblCls" onclick="addCustomerNewPaymentPending()">&plus;</label>
						</div>
						<div class="salesProjectAddProductAddLblMainRowCls">
							<label class="salesProjectProdctAddInnerHdrLblCls" onclick="subCustomerNewPaymentPending()">&minus;</label>
						</div>
					</div>
					<div class="salesProjectSupplierDetailsEnterRowCls">
						<input type="text" class="salesProjectSupplierDetailsAddDetailsTextCls" id="addCustomer_payment_pending_txt" autocomplete="off">
					</div>
				</div>
				<div class="salesProjectProductAddInnerFtrRowCls">
					<button class="itemClearSalesBtnCls" onclick="clearAllCustomerText()">Clear</button>
					<button class="itemSubmitSalesBtnCls" onclick="updateNewCustomer()">Update</button>
				</div>
		</div>	`;
		return addCustomerForm;
	}

	function customerDynamicRowHTML(customerName,area,phoneNo,cashInHand,paymentPending){
		var row = `<div class="salesProjectItemBodyBdyInnerTRowCls">
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+customerName+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+area+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+phoneNo+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+cashInHand+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow1Cls">
							<label class="salesProjectItemBodyBdyInnerTdLblCls">`+paymentPending+`</label>
						</div>
						<div class="salesProjectItemBodyBdyInnerTdRow2Cls">
							<label class="salesProjectItemBodyBdyInnerTdLbl1Cls" onclick="deleteCustomerDynamicRowHTML(this)">&times;</label>
						</div>
					</div>`;
		return row;
	}

	function hideCustomerDetailsForm(){
		document.getElementById("salesProjectCustomerAddForm").style.display ="none";
	} 



	function updateNewCustomer(){

		try{
			var customerName = document.getElementById("addCustomer_customer_name_txt").value;
			var area = document.getElementById("addCustomer_area_txt").value;
			var phoneNo = document.getElementById("addCustomer_phone_no_txt").value;
			var cashInHand = document.getElementById("addCustomer_cash_in_hand_txt").value;
			var paymentPending = document.getElementById("addCustomer_payment_pending_txt").value;
		
			var bodyContainer = document.getElementById("customerlist_body_container");
			var bodyContainerInnerHTML = document.getElementById("customerlist_body_container").innerHTML;
			var row = customerDynamicRowHTML(customerName,area,phoneNo,cashInHand,paymentPending);
			bodyContainer.innerHTML = bodyContainerInnerHTML + row;

			document.getElementById("salesProjectCustomerAddForm").style.display ="none";
			document.getElementById("salesProjectMainForm").style.display = "block";
		
		}catch(exp){
			alert(exp);
		}

	}

	function deleteCustomerDynamicRowHTML(obj){
		obj.parentNode.parentNode.remove();
	}

	function addCustomerNewCashInHand(){
		try{
			var newCashInHand = prompt("Add Cash In Hand :");
			if(newCashInHand != null){
				newCashInHand = parseInt(newCashInHand);
				var oldCashInHand = document.getElementById("addCustomer_cash_in_hand_txt").value;
				document.getElementById("addCustomer_cash_in_hand_txt").value = oldCashInHand+newCashInHand;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function subCustomerNewCashInHand(){
		try{
			var newCashInHand = prompt("Sub Cash In Hand :");
			if(newCashInHand != null){
				newCashInHand = parseInt(newCashInHand);
				var oldCashInHand = document.getElementById("addCustomer_cash_in_hand_txt").value;
				document.getElementById("addCustomer_cash_in_hand_txt").value = oldCashInHand-newCashInHand;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function addCustomerNewPaymentPending(){
		try{
			var newPaymentPending = prompt("Add Payment Pending :");
			if(newPaymentPending != null){
				newPaymentPending = parseInt(newPaymentPending);
				var oldPaymentPending = document.getElementById("addCustomer_payment_pending_txt").value;
				document.getElementById("addCustomer_payment_pending_txt").value = oldPaymentPending+newPaymentPending;
			}
		}catch(exp){
			alert(exp);
		}
	}

	function subCustomerNewPaymentPending(){
		try{
			var newPaymentPending = prompt("Sub Payment Pending :");
			if(newPaymentPending != null){
				newPaymentPending = parseInt(newPaymentPending);
				var oldPaymentPending = document.getElementById("addCustomer_payment_pending_txt").value;
				document.getElementById("addCustomer_payment_pending_txt").value = oldPaymentPending-newPaymentPending;
			}
		}catch(exp){
			alert(exp);
		}
	}