function getAddItemForm(){
		var addItemForm = `
			<div class="salesProjectProductAddInnerFormCls">
				<div class="salesProjectProductAddInnerHdrRowCls">
					
					<div class="salesProjectAddProductHdrLblRowCls">
						<label class="salesProjectProdctAddInnerMainHdrLblCls">Item</label>
					</div>
					<div class="salesProjectAddProductAddLblMainRowCls" >
						<label class="salesProjectProdctAddInnerMainHdrLblCls" onclick= "hideItemForm()">&times;</label>
					</div>
				</div>
				<div class="salesProjectProductAddInnerBodyRowCls">
					<div class="salesProjectProductAddInnerBodyRow1Cls">
						<div class="salesprojectProductAddDetailsRow1Cls">
							<div class="salesProjectProductEnterRowCls">
								<label class="salesProjectProdctAddDetailsLblCls">Item name</label>
							</div>
							<div class="salesProjectProductEnterRowCls">
								<input type="text" class="salesProjectProductAddDetailsTextCls" id="itemform_itemname_text" autocomplete="off">
							</div>
							<div class="salesProjectProductEnterRowCls">
								<label class="salesProjectProdctAddDetailsLblCls">Primary Unit</label>
							</div>
							<div class="salesProjectProductEnterRowCls">
								<select class="salesProjectProductAddDetailsTextCls"  id="itemform_primaryunit_text" autocomplete="off">
									<option>.Kg </option>
									<option>.g</option>
									<option>.ltr</option>
									<option>.mg</option>
									<option>.tonne</option>
								</select>
							</div>
							<div class="salesProjectProductEnterRowCls">
								<label class="salesProjectProdctAddDetailsLblCls">Quatity</label>
							</div>
							<div class="salesProjectProductEnterRowCls">
								<input type="text" class="salesProjectProductAddDetailsTextCls"  id="itemform_quatity_text" autocomplete="off">
							</div>
						</div>
						<div class="salesprojectProductAddDetailsRow2Cls">
							<div class="salesProjectAddProductDetailsImageRowCls">
								<img src="" class="salesProductAddItemImgCls" id="itemform_image_tag">
							</div>
							<div class="salesProjectProductEnterRowCls">
								<input type="file" class="salesProjectProductAddDetailsTextCls"  id="itemform_location_text" autocomplete="off" onchange="uploadItemImageLocation(this,event)">
								<!--<button class="salesProjectProductAddDetailsTextCls" style="color:white;background:grey;" onclick="uploadItemImageLocation()">Location</button>-->
							</div>
						</div>
					</div>
					<div class="salesProjectProductAddInnerBodyRow1Cls">
						<div class="salesProjectProductAddInnerBodyHdrRowCls">
							<div class="salesProjectAddProductHdrLblRowCls">
								<label class="salesProjectProdctAddInnerHdrLblCls">Sales Categories</label>
							</div>
							<div class="salesProjectAddProductAddLblRowCls">
								<label class="salesProjectProdctAddInnerHdrLblCls">Add</label>
							</div>
						</div>
						<div class="salesProjectProductAddInnerBodyBodyRowCls" id="newItem_sales_category_body_container">
						</div>
					</div>
					<div class="salesProjectProductAddInnerBodyRow1Cls">
						<div class="salesProjectProductAddInnerBodyHdrRowCls">
							<div class="salesProjectAddProductHdrLblRowCls">
								<label class="salesProjectProdctAddInnerHdrLblCls">Supplier Categories</label>
							</div>
							<div class="salesProjectAddProductAddLblRowCls">
								<label class="salesProjectProdctAddInnerHdrLblCls">Add</label>
							</div>
						</div>
						<div class="salesProjectProductAddInnerBodyBodyRowCls" id="newItem_supplier_category_body_container">
						</div>
					</div>
				</div>
				<div class="salesProjectProductAddInnerFtrRowCls">
					<button class="itemClearSalesBtnCls" onclick= "clearAllItemText()">Clear</button>
					<button class="itemSubmitSalesBtnCls" onclick="updateNewItem()">Submit</button>
				</div>
			</div>	`;
		return addItemForm;
	}


function uploadItemImageLocation(inputObj,e){
	try{
		var imageTag = document.getElementById("itemform_image_tag");
		imageTag.setAttribute("src","./images/"+e.target.files[0].name);
		alert(imageTag.src);
	}catch(exp){
		alert(exp);
	}
}




function itemDynamicRowHTML(itemName,primaryUnit,quatity){
	var row = `<div class="salesProjectItemBodyBdyInnerTRowCls"><div class="salesProjectItemBodyBdyInnerTdRow1Cls"><label class="salesProjectItemBodyBdyInnerTdLblCls">`+itemName+`</label></div><div class="salesProjectItemBodyBdyInnerTdRow1Cls"><label class="salesProjectItemBodyBdyInnerTdLblCls">`+primaryUnit+`</label></div><div class="salesProjectItemBodyBdyInnerTdRow1Cls"><label class="salesProjectItemBodyBdyInnerTdLblCls">`+quatity+`</label></div><div class="salesProjectItemBodyBdyInnerTdRow2Cls"><label class="salesProjectItemBodyBdyInnerTdLbl1Cls" onclick="deleteItemDynamicRowHTML(this)">&times;</label></div></div>`;
	return row;
}

function updateNewItem(){
	try{
		var itemname 	= document.getElementById("itemform_itemname_text").value;
		var primaryUnit = document.getElementById("itemform_primaryunit_text").value;
		var quatity 	= document.getElementById("itemform_quatity_text").value;
		var Locationpath= document.getElementById("itemform_location_text").value;
	
		var itemBodyContainer = document.getElementById("itemlist_body_container");
		var itemBodyContainerInnerHTML = document.getElementById("itemlist_body_container").innerHTML;
		var row = itemDynamicRowHTML(itemname,primaryUnit,quatity);
		itemBodyContainer.innerHTML = itemBodyContainerInnerHTML + row;

		document.getElementById("salesProjectItemAddForm").style.display ="none";
		document.getElementById("salesProjectMainForm").style.display = "block";
	
	}catch(exp){
		alert(exp);
	}
}

function hideItemForm(){
	document.getElementById("salesProjectItemAddForm").style.display ="none";
}