function getMenuListForm(){

	var menuListForm = `<div class="salesProjectInnerMenuBoxCls" onclick="showBillingForm()" onmousedown="selectedMenuListContainer(this)"><div 
					class="salesProjectInnerMenuBoxImgRowCls"><img src="./images/bluebill.png" class="salesProjectInnerMenuBoxImg1Cls"><img
					 src="./images/greybill.png" class="salesProjectInnerMenuBoxImg2Cls"></div><div
					  class="salesProjectInnerMenuBoxLblCls"><label class="salesProjectInnerMenuLblCls">Billing</label></div></div><div
					   class="salesProjectInnerMenuBoxCls" onclick="showProductAndItemForm()" onmousedown="selectedMenuListContainer(this)"><div
					    class="salesProjectInnerMenuBoxImgRowCls"><img src="./images/blueProduct.png" class="salesProjectInnerMenuBoxImg1Cls"><img
					     src="./images/greyProduct.png" class="salesProjectInnerMenuBoxImg2Cls"></div><div
					      class="salesProjectInnerMenuBoxLblCls"><label
					       class="salesProjectInnerMenuLblCls">Product</label></div></div><div
					        class="salesProjectInnerMenuBoxCls" onclick="showCustomerForm()" onmousedown="selectedMenuListContainer(this)"><div
					         class="salesProjectInnerMenuBoxImgRowCls"><img 
					         src="./images/bluecustomer.png" class="salesProjectInnerMenuBoxImg1Cls"><img
					          src="./images/greycustomer.png" class="salesProjectInnerMenuBoxImg2Cls"></div><div
					           class="salesProjectInnerMenuBoxLblCls"><label
					            class="salesProjectInnerMenuLblCls">Customer</label></div></div><div
					             class="salesProjectInnerMenuBoxCls" onclick="showSupplierForm()" onmousedown="selectedMenuListContainer(this)"><div
					              class="salesProjectInnerMenuBoxImgRowCls"><img
					               src="./images/bluesupplier.png" class="salesProjectInnerMenuBoxImg1Cls"><img
					                src="./images/greysupplier.png" class="salesProjectInnerMenuBoxImg2Cls"></div><div
					                 class="salesProjectInnerMenuBoxLblCls"><label
					                  class="salesProjectInnerMenuLblCls">Supplier</label></div></div>`;
	return menuListForm;
}

function openCloseMenuListInSalesProject(){
	try{
		var menuBodyContainer = document.getElementById("salesProjectMenuBodyContainer");
		if(menuBodyContainer.style.height == "0%"){
			menuBodyContainer.style.height = "70%";
			setTimeout(function(){
				menuBodyContainer.innerHTML = getMenuListForm();
			},1000);
		}else{
			menuBodyContainer.innerHTML = "";
			setTimeout(function(){
				menuBodyContainer.style.height = "0%";
			},500);
		}
	}catch(exp){
		alert(exp);
	}
}


	function showBillingForm(){
		hideAllInnerForm();
		document.getElementById("salesProjectBillingForm").style.display = "block";
		document.getElementById("salesProjectBillingForm").innerHTML = getBillingForm();
	}

	function showProductAndItemForm(){
		hideAllInnerForm();
		document.getElementById("salesProjectPdtAndItmForm").style.display = "block";
		document.getElementById("salesProjectPdtAndItmForm").innerHTML = getProductAndItemSalesForm();
	}

	function showSupplierForm(){
		hideAllInnerForm();
		document.getElementById("salesProjectSupplierListForm").style.display = "block";
		document.getElementById("salesProjectSupplierListForm").innerHTML = getSupplierForm();
	}


	function showCustomerForm(){
		hideAllInnerForm();
		document.getElementById("salesProjectCustomerListForm").style.display = "block";
		document.getElementById("salesProjectCustomerListForm").innerHTML = getCustomerForm();
	}

	function selectedMenuListContainer(selectObj){
		try{
			var menuBodyContainer = document.getElementById("salesProjectMenuBodyContainer");
			for(var i = 0; i < menuBodyContainer.childNodes.length; i++){
				var menuContainer = menuBodyContainer.childNodes[i];
				menuContainer.className = "salesProjectInnerMenuBoxCls";
				menuContainer.childNodes[0].childNodes[0].className = "salesProjectInnerMenuBoxImg1Cls";
				menuContainer.childNodes[0].childNodes[1].className = "salesProjectInnerMenuBoxImg2Cls";
				menuContainer.childNodes[1].childNodes[0].className = "salesProjectInnerMenuLblCls";
			}

			selectObj.className = "salesProjectInnerSelectedMenuBoxCls";
			selectObj.childNodes[0].childNodes[0].className = "salesProjectInnerMenuBoxImg3Cls";
			selectObj.childNodes[0].childNodes[1].className = "salesProjectInnerMenuBoxImg4Cls";
			selectObj.childNodes[1].childNodes[0].className = "salesProjectInnerSelectedMenuLblCls";
		}catch(exp){
			alert(exp);
		}
	}
