function getCustomerForm(){
	
		var customerForm = `<div class="salesProjectCustomerHeaderRowCls">
						<div class="salesProjectCustomerHdrLblRowCls">
							<label class="salesProjectCustomerHdrLblCls">Customer Details</label>
						</div>
						<div class="salesProjectBillingRightHdrLblRowCls">
							<select class="salesProjectBillingRightProductSelectList2Cls" id="customer_name_or_area_or_phone_select_tag">
								<option>Name </option>
								<option>Area </option>
								<option>Phone </option>
							</select>
						</div>
						<div class="salesProjectCustomerAddLblRowCls" onclick="customerFormSearch()">	
							<label class="salesProjectCustomerHdr1LblCls">Search</label>
						</div>
						<div class="salesProjectCustomerAddLblRowCls"  onclick="showCustomerDetailsForm()">
							<label class="salesProjectCustomerHdr1LblCls">Add</label>
						</div>
					</div>
					<div class="salesProjectCustomerBodyRowCls">
						<div class="salesProjectItemBodyHdrInnerTHeadCls">
						 
							<div class="salesProjectItemBodyInnerTHRow1Cls">Customer Name</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Area</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Phone</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Cash In Hand</div>
							<div class="salesProjectItemBodyInnerTHRow1Cls">Payment Pending</div>
						</div>
						<div class="salesProjectItemBodytBodyInnerRowCls" id="customerlist_body_container">
							
						<div>
					</div>`;
		return customerForm;
	}



function clearAllCustomerText(){
	document.getElementById("addCustomer_customer_name_txt").value = "";
	document.getElementById("addCustomer_area_txt").value = "";
	document.getElementById("addCustomer_phone_no_txt").value = "";
	document.getElementById("addCustomer_cash_in_hand_txt").value = "";
	document.getElementById("addCustomer_payment_pending_txt").value = "";

}

function showCustomerDetailsForm(){
	hideAllForm();
	document.getElementById("salesProjectMainForm").style.display ="block";
	document.getElementById("salesProjectCustomerAddForm").style.display ="block";
	clearAllCustomerText();
}

function customerFormSearch(){
		var typeOfSearch = document.getElementById("customer_name_or_area_or_phone_select_tag").value;
		if(typeOfSearch == "Name"){
			var name = prompt("Enter the name to search :");
		}else if(typeOfSearch == "Area"){
			var area = prompt("Enter the area to search :");
		}else if(typeOfSearch == "Phone"){
			var phoneNo = prompt("Enter the phone number to search :");
		}else{

		}
}