function getProductAndItemSalesForm(){
	var productAndItemSalesForm = `
			<div class="salesProjectProductContainerCls">
				<div class="salesProjectProductHeaderRowCls">
					<div class="salesProjectProductHdrLblRowCls">
						<label class="salesProjectProductHdrLblCls">Product</label>
					</div>
					<div class="salesProjectProductAddLblRowCls" onclick="addNewProduct()">
						<label class="salesProjectProductHdr1LblCls">&plus;</label>
					</div>
				</div>
				<div class="salesProjectProductBodyRowCls" id="product_body_container">
				</div>
			</div>
			<div class="salesProjectItemContainercls">
				<div class="salesProjectItemHeaderRowCls">
					<div class="salesProjectItemHdrLblRowCls">
						<label class="salesProjectItemHdrLblCls">Item</label>
					</div>
					<div class="salesProjectItemAddLblRowCls" onclick = "showAddItemForm()">
						<label class="salesProjectItemHdr1LblCls">Add</label>
					</div>
				</div>
				<div class="salesProjectItemBodyRowCls" >
					<div class="salesProjectItemBodyHdrInnerTHeadCls">
					 
						<div class="salesProjectItemBodyInnerTHRow1Cls">Item Name</div>
						<div class="salesProjectItemBodyInnerTHRow1Cls">Primary Unit</div>
						<div class="salesProjectItemBodyInnerTHRow1Cls">Quatity</div>
					
					</div>
					<div class="salesProjectItemBodytBodyInnerRowCls" id="itemlist_body_container">
						
					<div>
				</div>
			</div>`;
	return productAndItemSalesForm;
}


function productDynamicRowHTML(newProductObj){
	var row = `<div class="salesProjectProductDynamicrowCls"><div class="salesProjectProductDymRowInnerLblCls"><label class="salesProjectProductDymInnerLblCls">`+newProductObj+`</label></div><div class="salesProjectProductDymRowInnericonCls"><label class="salesProjectProductDymInnerLblCls" onclick = "deleteProductDynamicRowHTML(this)">&times;</label></div></div>`;
	return row;
}

function addNewProduct(){
	try{
		var newProduct = prompt("Enter the New Product :");
		if(newProduct != null){
			var productBodyContainer = document.getElementById("product_body_container");
			var productBodyContainerInnerHTML = document.getElementById("product_body_container").innerHTML;
			var row = productDynamicRowHTML(newProduct);
			productBodyContainer.innerHTML=productBodyContainerInnerHTML + row;
		}
	}catch(exp){
		alert(exp);
	}
}

function deleteProductDynamicRowHTML(obj){
	obj.parentNode.parentNode.remove();
}

function clearAllItemText(){
	document.getElementById("itemform_itemname_text").value = "";
	document.getElementById("itemform_primaryunit_text").value = "";
	document.getElementById("itemform_quatity_text").value = "";
	document.getElementById("itemform_location_text").value = "";
	document.getElementById("itemform_image_tag").src = "";
	document.getElementById("newItem_sales_category_body_container").innerHTML = "";
	document.getElementById("newItem_supplier_category_body_container").innerHTML = "";

}

function showAddItemForm(){
	hideAllForm();
	document.getElementById("salesProjectMainForm").style.display = "block";
	document.getElementById("salesProjectItemAddForm").style.display = "block";
	clearAllItemText();		
}
	
function deleteItemDynamicRowHTML(obj){
	obj.parentNode.parentNode.remove();
}